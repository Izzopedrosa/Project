<?php
// connect to the database
$conn = mysqli_connect("admission-rds.c3gskywgqkaj.ap-southeast-2.rds.amazonaws.com", "admin", "", "UnlockRDS25");
// Check for connection errors
if (mysqli_connect_errno()) {
  die("Connection Fail" . mysqli_connect_error());
}
